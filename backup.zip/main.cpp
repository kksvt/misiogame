#include "Entity.h"
#include "debugdraw.h"

#include <iostream>
#include <vector>

#include <Box2D\Box2D.h>

const float P2M = 16.f;
const float M2P = 1.0f / P2M;

int main()
{
    sf::RenderWindow window(sf::VideoMode({ 1280, 720 }), "SFML works!");
    window.setFramerateLimit(60);
    sf::Clock game_clock;
    
    b2Version version = b2GetVersion();
    printf("Box2D version %d.%d.%d\n", version.major, version.minor, version.revision);

    b2Vec2 gravity = { 0.f, 9.8f };
    b2WorldDef world_def = b2DefaultWorldDef();
    world_def.gravity = gravity;
    b2WorldId world_id = b2CreateWorld(&world_def);

    SFMLDebugDrawContext ctx = { &window, P2M };

    b2DebugDraw debug_draw;
    SetupB2DebugDraw_SFML(debug_draw, ctx);

    //static body
    b2BodyDef ground_body_def = b2DefaultBodyDef();
    ground_body_def.position = {10.0f, 10.f};

    b2BodyId ground_id = b2CreateBody(world_id, &ground_body_def);
    b2Polygon ground_box = b2MakeBox(5.f, 1.f);

    b2ShapeDef ground_shape_def = b2DefaultShapeDef();
    b2CreatePolygonShape(ground_id, &ground_shape_def, &ground_box);

    //dynamic body
    b2BodyDef body_def = b2DefaultBodyDef();
    body_def.type = b2_dynamicBody;
    body_def.position = { 10.0f, 4.0f };

    b2BodyId body_id = b2CreateBody(world_id, &body_def);
    b2Polygon dynamic_box = b2MakeBox(1.0f, 1.0f);

    b2ShapeDef shape_def = b2DefaultShapeDef();
    shape_def.density = 1.0f;
    shape_def.material.friction = 0.3f;

    b2CreatePolygonShape(body_id, &shape_def, &dynamic_box);

    float time_step = 1.0f / 60.f;
    int sub_step_count = 4;

    double t = 0.0;
    double dt = 0.01;

    while (window.isOpen())
    {
        while (const std::optional event = window.pollEvent())
        {
            if (event->is<sf::Event::Closed>())
                window.close();

        }

        
        printf("%i\n", game_clock.getElapsedTime().asMilliseconds());

        b2World_Step(world_id, time_step, sub_step_count);
        b2Vec2 position = b2Body_GetPosition(body_id);
        b2Rot rotation = b2Body_GetRotation(body_id);
        printf("%4.2f %4.2f %4.2f\n", position.x, position.y, b2Rot_GetAngle(rotation));

        window.clear();

        b2World_Draw(world_id, &debug_draw);

        window.display();
    }

    b2DestroyWorld(world_id);
}