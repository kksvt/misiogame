#pragma once
#include "Entity.h"

class PhysicsManager {
public:
	static void run();
};