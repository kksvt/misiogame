#pragma once
#include <SFML/Graphics.hpp>
#include "EntityComponent.h"
#include <unordered_map>

class Entity {
private:
	uint32_t _id;
	std::string _name;
	std::unordered_map<EntityComponentType, EntityComponentPtr> _components;
	Entity(uint32_t id, std::string name) : _id(id), _name(name) {}
public:
	void process_components(const int32_t dt);
	bool add_component(EntityComponentPtr component);
	bool remove_component(EntityComponentType component_type);

	template <typename T>
	T* get_component(EntityComponentType component_type);
};