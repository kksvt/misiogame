#include "Entity.h"
#include <iostream>

void Entity::process_components(const int32_t dt)
{
	for (auto& [_, component] : _components) {
		component->process(dt);
	}
}

bool Entity::add_component(EntityComponentPtr component)
{
	auto type = component->get_type();
	if (_components.find(type) != _components.end()) {
		std::cerr << "Trying to add duplicate component [" << EntityComponent::ComponentName(type) << ", " << type << "] to entity ["
			<< this->_name << ", " << this->_id << "]\n";
		return false;
	}
	_components.insert(std::make_pair(type, std::move(component)));
	return true;
}

bool Entity::remove_component(EntityComponentType component_type)
{
	auto it = _components.find(component_type);
	if (it == _components.end()) {
		std::cerr << "Trying to remove a non-existent component [" << EntityComponent::ComponentName(component_type) << ", " << component_type << "] from entity ["
			<< this->_name << ", " << this->_id << "]\n";
		return false;
	}
	_components.erase(it);
	return true;
}

template<typename T>
T* Entity::get_component(EntityComponentType component_type)
{
	auto it = _components.find(component_type);
	if (it == _components.end()) {
		return (T*)nullptr;
	}
	return dynamic_cast<T*>(it->second.get());
}