#include "EntityComponent.h"

const char* EntityComponent::_componentNames[ENTITY_COMPONENT_MAX] = {
	ENUM2STR(ENTITY_NONE),
	ENUM2STR(ENTITY_SPRITE),
	ENUM2STR(ENTITY_PHYSICS),
};

const char* EntityComponent::ComponentName(EntityComponentType type)
{
	if (type < 0 || type >= ENTITY_COMPONENT_MAX) {
		return "[invalid]";
	}
	return _componentNames[type];
}
