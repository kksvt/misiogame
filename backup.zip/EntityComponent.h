#pragma once
#include <SFML/System.hpp>

#define ENUM2STR(x) #x

class Entity;

enum EntityComponentType {
	ENTITY_NONE = 0,
	ENTITY_SPRITE,
	ENTITY_PHYSICS,
	ENTITY_COMPONENT_MAX,
};

class EntityComponent {
	friend class Entity;
private:
	EntityComponentType _type;
	static const char* _componentNames[ENTITY_COMPONENT_MAX];
public:
	EntityComponent(EntityComponentType type) : _type(type) {

	}

	virtual void process(const int32_t dt) {};
	EntityComponentType get_type() { return _type; }

	static const char* ComponentName(EntityComponentType type);
};

typedef std::unique_ptr<EntityComponent> EntityComponentPtr;