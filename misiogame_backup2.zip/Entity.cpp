#include "Entity.h"

void Entity::update(uint64_t time) {
	if (sprite_) {
		sprite_->update(time);
		if (physics_) {
			sprite_->set_position(physics_->get_position());
			auto v = physics_->get_velocity();
			if (v.x > 0) {
				sprite_->set_flipped(false);
			}
			else if (v.x < 0) {
				sprite_->set_flipped(true);
			}
		}
	}
}