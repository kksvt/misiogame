#pragma once

#include "Entity.h"
#include <vector>
#include <set>

class EntityManager {
public:
	static int create_empty_entity(const std::string& name);
	static Entity* create_player(const std::string& sprite_path, 
		float width, float height, float pos_x, float pos_y,
		const std::initializer_list<uint8_t>& num_frames,
		const std::initializer_list<uint8_t>& animation_speed);
	static void update(uint64_t time);
	static void remove(int entity_num);
private:
	EntityManager();
	static std::vector<EntityPtr_t> all_entities_;
	static std::set<int> remove_entities_;
};