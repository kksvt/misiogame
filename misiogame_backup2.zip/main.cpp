#include "Entity.h"

#include <iostream>
#include <vector>

#include <box2d\box2d.h>
#include "PhysicsManager.h"
#include "TextureManager.h"

#include "SpriteComponent.h"

const float pixels_per_meter = 32.f;
const float meters_per_pixel = 1.0f / pixels_per_meter;

int main()
{
    sf::RenderWindow window(sf::VideoMode({ 1280, 720 }), "SFML works!");
    window.setFramerateLimit(60);
    sf::Clock game_clock;

    const float fixed_dt = 1.f / 60.f;
    const float maxframetime = 0.25f;
    const int max_steps_per_frame = 8;

    float acc = 0.f;
    
    auto last_time = game_clock.getElapsedTime().asMilliseconds();

    auto last_flip = last_time;

    b2Version version = b2GetVersion();
    printf("Box2D version %d.%d.%d\n", version.major, version.minor, version.revision);

    PhysicsManager::init(9.8f, pixels_per_meter, meters_per_pixel, 4);
    PhysicsManager::init_debug_draw(window);

    PhysicsComponentPtr_t obj1(new PhysicsComponent_t(
        PhysicsManager::world_id, true, 24.f, 28.f, 0.f, 0.f
    ));

    PhysicsComponentPtr_t obj2(new PhysicsComponent_t(
        PhysicsManager::world_id, false, 512.f, 64.f, 0.f, 256.f
    ));

    SpriteComponentPtr_t sprite1(new SpriteComponent_t("crudewalk.png", sf::IntRect({ 0, 0 }, { 24, 28 }), { 6, 6 }, { 100, 100 }));

    sprite1->set_row(1);

    while (window.isOpen())
    {
        while (const std::optional event = window.pollEvent())
        {
            if (event->is<sf::Event::Closed>())
                window.close();
            else if (const auto* keyPressed = event->getIf<sf::Event::KeyPressed>())
            {
                if (keyPressed->scancode == sf::Keyboard::Scancode::A) {
                    obj1->move({ -1.f, 0 }, 8);
                }
                else if (keyPressed->scancode == sf::Keyboard::Scancode::D) {
                    obj1->move({ 1.f, 0 }, 8);
                }
            }

        }
        
        //printf("%i\n", game_clock.getElapsedTime().asMilliseconds());

        //window.draw(sprite);

        auto total_time = game_clock.getElapsedTime().asMilliseconds();

        if (total_time - last_flip > 1000) {
            sprite1->set_flipped(!sprite1->get_flipped());
            last_flip = total_time;
        }

        auto frametime = std::min(maxframetime, (total_time - last_time) / 1000.f);
        acc += frametime;

        int steps;
        for (steps = 0; acc >= fixed_dt && steps < max_steps_per_frame; ++steps, acc -= fixed_dt) {
            PhysicsManager::run(fixed_dt);
        }

        if (steps >= max_steps_per_frame) {
            acc = 0.f;
        }

        window.clear();

        PhysicsManager::draw();

        sprite1->set_position(obj1->get_position());
        sprite1->update(total_time);

        window.draw(sprite1->get_sprite());

        window.display();

        last_time = total_time;
    }

    PhysicsManager::destroy();
}