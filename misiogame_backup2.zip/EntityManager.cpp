#include "EntityManager.h"
#include <iostream>

int EntityManager::create_empty_entity(const std::string& name)
{
    int i;
    for (i = 0; i < all_entities_.size(); ++i) {
        if (!all_entities_[i]) {
            break;
        }
    }
    EntityPtr_t new_ent(new Entity(i, name));
    if (i == all_entities_.size()) {
        all_entities_[i] = std::move(new_ent);
    }
    else {
        all_entities_.push_back(std::move(new_ent));
    }
    return i;
}

Entity* EntityManager::create_player(const std::string& sprite_path, 
    float width, float height, float pos_x, float pos_y,
    const std::initializer_list<uint8_t>& num_frames,
    const std::initializer_list<uint8_t>& animation_speed)
{
    int entity_num = create_empty_entity("player");
    Entity* player = all_entities_[entity_num].get();
    PhysicsComponentPtr_t physics(new PhysicsComponent_t(
        PhysicsManager::world_id, true, width, height, pos_x, pos_y
    ));
    SpriteComponentPtr_t sprite(new SpriteComponent_t(
        sprite_path, sf::IntRect({ 0, 0 }, {width, height}), 
        num_frames, animation_speed ));
    player->physics_ = std::move(physics);
    player->sprite_ = std::move(sprite);

    std::cout << "Player character created as entity number " << entity_num << '\n';

    return player;
}

void EntityManager::remove(int entity_num)
{

}
